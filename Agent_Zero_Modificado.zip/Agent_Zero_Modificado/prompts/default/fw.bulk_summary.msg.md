# Message history to summarize:
{{content}}