# Instruction
- provide a chat name for the following

# Current chat name
{{current_name}}

# Chat history
{{history}}
