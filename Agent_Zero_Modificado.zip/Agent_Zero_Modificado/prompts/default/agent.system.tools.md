## Tools available:

{{ include './agent.system.tool.response.md' }}

{{ include './agent.system.tool.call_subordinate.md' }}

{{ include './agent.system.tool.behaviour.md' }}

{{ include './agent.system.tool.search_engine.md' }}

{{ include './agent.system.tool.memory.md' }}

{{ include './agent.system.tool.code_exe.md' }}

{{ include './agent.system.tool.input.md' }}

{{ include './agent.system.tool.browser.md' }}

{{ include './agent.system.tool.scheduler.md' }}
